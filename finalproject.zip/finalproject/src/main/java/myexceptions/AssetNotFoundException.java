package myexceptions;

public class AssetNotFoundException extends Exception {
		public AssetNotFoundException(String text) {
			super(text);
		}
}
