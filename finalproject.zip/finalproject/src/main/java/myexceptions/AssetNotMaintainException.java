package myexceptions;

public class AssetNotMaintainException extends Exception {
			public AssetNotMaintainException(String text) {
				super(text);
			}
}
